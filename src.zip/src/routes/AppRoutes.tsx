import { Navigate, Route, Routes } from 'react-router';
import TodoListPage from '../pages/TodoListPage';
import UserProfilePage from '../pages/UserProfilePage';

import AuthPage from '../pages/AuthPage';
import RegistrationPage from '../pages/RegistrationPage';
import MenuComponent from '../components/MenuComponent/MenuComponent';

const AppRoutes = () => {
    return (
        <Routes>
            <Route path='/' element={<MenuComponent/>}>

                <Route index element={<Navigate to="auth/login" replace />} />

                <Route path='dashboard/todo' element={<TodoListPage/>}/>
                <Route path='dashboard/user' element={<UserProfilePage/>}/>
                <Route path='auth/login' element={<AuthPage/>}/>
                <Route path='auth/registration' element={<RegistrationPage/>}/>

            </Route>
        </Routes>
    );
};

export default AppRoutes;