import UserProfile from '../components/UserProfile/UserProfile';

const UserProfilePage = () => {
    return (
        <UserProfile/>
    );
};

export default UserProfilePage;