import React from 'react';
import styles from './style.module.scss';

const UserProfile: React.FC = () => {
    return (
        <div className={styles.wrapper}>
            <span>Привет</span>
        </div>
    );
};

export default UserProfile;